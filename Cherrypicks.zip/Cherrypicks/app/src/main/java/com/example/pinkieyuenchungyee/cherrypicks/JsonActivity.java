package com.example.pinkieyuenchungyee.cherrypicks;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class JsonActivity extends AppCompatActivity {

    String DateString, TimeString, JsonString;
    public static final String JsonURL = "https://workbcjobs.api.gov.bc.ca/v1/jobs";
    String TAG = "JsonActivity";
    String jobID, jobTitle,employerName,jobDescription,postedDate, expiryDate, salaryType, salaryMultiplier, salaryMin, salaryMax, majorProject;

    private ArrayAdapter<String> adapter;
    private ArrayList<String> arrayList;

    ArrayList<HashMap<String, String>> jobInfoList;
    private ListView lv;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_json);

        jobInfoList = new ArrayList<>();

        lv = findViewById(R.id.list);
        arrayList = new ArrayList<String>();

        RequestQueue queue = Volley.newRequestQueue(this);

        Intent intent = getIntent();
        int mYear = intent.getIntExtra("Year", 0);
        int mMonth = intent.getIntExtra("Month", 0);
        int mDay = intent.getIntExtra("Day", 0);
        int mHour = intent.getIntExtra("Hour", 0);
        int mMinute = intent.getIntExtra("Minute", 0);

        if (mMonth < 10 && mDay < 10)
            DateString = mYear + "-" + "0" + mMonth + "-" + "0" + mDay;
        else if (mMonth < 10)
            DateString = mYear + "-" + "0" + mMonth + "-" + mDay;
        else if (mDay < 10)
            DateString = mYear + "-" + mMonth + "-" + "0" + mDay;
        else
            DateString = mYear + "-" + mMonth + "-" + mDay;

        if (mHour < 10 && mMinute < 10)
            TimeString = "0" + mHour + ":" + "0" + mMinute;
        else if (mHour < 10)
            TimeString = "0" + mHour + ":" + mMinute;
        else if (mMinute < 10)
            TimeString = mHour + ":" + "0" + mMinute;
        else
            TimeString = mHour + ":" + mMinute;

        JsonString = DateString + "T" + TimeString + ":" + "00";

        Log.d("FinalString : ", JsonString);
        /*----------------------------------------------------------------------------------------------------------------*/


        SendPostRequest(JsonString);

    }


    public void SendPostRequest(final String JSONString) {

        RequestQueue requestQueue = Volley.newRequestQueue(this);

        StringRequest req = new StringRequest(Request.Method.POST, JsonURL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d(TAG, response);
                        try {
                            JSONObject ResponseJsonObject = new JSONObject(response);
                            JSONArray ResponseJsonArray = ResponseJsonObject.getJSONArray("jobs");
                            for(int i = 0; i < ResponseJsonArray.length();i++){
                                jobID = ResponseJsonArray.getJSONObject(i).getString("jobID");
                                jobTitle = ResponseJsonArray.getJSONObject(i).getString("jobTitle");
                                employerName = ResponseJsonArray.getJSONObject(i).getString("employerName");
                                jobDescription = ResponseJsonArray.getJSONObject(i).getString("jobDescription");
                                postedDate = ResponseJsonArray.getJSONObject(i).getString("postedDate");
                                expiryDate = ResponseJsonArray.getJSONObject(i).getString("expiryDate");
                                salaryType = ResponseJsonArray.getJSONObject(i).getString("salaryType");
                                salaryMultiplier = ResponseJsonArray.getJSONObject(i).getString("salaryMultiplier");
                                salaryMin = ResponseJsonArray.getJSONObject(i).getString("salaryMin");
                                salaryMax = ResponseJsonArray.getJSONObject(i).getString("salaryMax");
                                majorProject = ResponseJsonArray.getJSONObject(i).getString("majorProject");


                                HashMap<String, String> jobInfo = new HashMap<>();
                                jobInfo.put("jobID",jobID);
                                jobInfo.put("jobTitle", jobTitle);
                                jobInfo.put("employerName", employerName);
                                jobInfo.put("jobDescription", jobDescription);
                                jobInfo.put("postedDate", postedDate);
                                jobInfo.put("expiryDate", expiryDate);
                                jobInfo.put("salaryType", salaryType);
                                jobInfo.put("salaryMultiplier", salaryMultiplier);
                                jobInfo.put("salaryMin", salaryMin);
                                jobInfo.put("salaryMax", salaryMax);
                                jobInfo.put("majorProject", majorProject);

                                jobInfoList.add(jobInfo);
                                ListAdapter adapter = new SimpleAdapter(
                                        JsonActivity.this, jobInfoList,
                                        R.layout.list_item, new String[]{"jobID", "jobTitle",
                                        "employerName", "jobDescription", "postedDate", "expiryDate",
                                        "salaryType", "salaryMultiplier", "salaryMin", "salaryMax", "majorProject"}, new int[]{R.id.jobID,
                                        R.id.jobTitle, R.id.employerName, R.id.jobDescription, R.id.postedDate, R.id.expiryDate, R.id.salaryType, R.id.salaryMultiplier,
                                R.id.salaryMin, R.id.salaryMax, R.id.majorProject});
                                lv.setAdapter(adapter);

                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d(TAG, error.toString());
                    }
                })
        {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("LastRequestDate", JSONString);
                return params;
            }
        };

        requestQueue.add(req);


    }


}