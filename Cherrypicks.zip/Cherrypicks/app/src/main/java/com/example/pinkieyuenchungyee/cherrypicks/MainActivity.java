package com.example.pinkieyuenchungyee.cherrypicks;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;

import com.android.volley.toolbox.JsonObjectRequest;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    public int mYear, mMonth, mDay, mHour, mMinute;
    TextView Date, Time, Title, LastRequestDate;
    Button GetJobInfo;
    private DatePickerDialog.OnDateSetListener mOnDateSetListener;
    private TimePickerDialog.OnTimeSetListener mOnTimeSetListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Date = findViewById(R.id.Date);
        Time = findViewById(R.id.Time);
        Title = findViewById(R.id.Title);
        LastRequestDate = findViewById(R.id.LastRequestDate);
        GetJobInfo = findViewById(R.id.GetJobInfo);

        LastRequestDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog alertDialog = new AlertDialog.Builder(MainActivity.this).create();
                alertDialog.setTitle("Last Request Date");
                alertDialog.setMessage("The date of the last request. Only job postings changed or deleted " +
                        "after this time will be included in the response. Default is today - 10 days.");
                alertDialog.show();
            }
        });


        Date.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(MainActivity.this,
                        android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                        mOnDateSetListener,
                        year, month, day);

                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();
            }
        });

        mOnDateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                mYear = i;
                mMonth = i1 + 1;
                mDay = i2;
                Log.d(TAG, "onDateSet: date: " + mYear + "/" + mMonth + "/" + mDay);
            }
        };


        Time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar cal = Calendar.getInstance();
                int hour = cal.get(Calendar.HOUR_OF_DAY);
                int minute = cal.get(Calendar.MINUTE);

                TimePickerDialog dialog = new TimePickerDialog(MainActivity.this,
                        android.R.style.Theme_Holo_Dialog_MinWidth,
                        mOnTimeSetListener,
                        hour, minute, true);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();
            }
        });

        mOnTimeSetListener = new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker timePicker, int i, int i1) {
                Log.d("OnTimePicker", i + "-" + i1);
                mHour = i;
                mMinute = i1;
            }
        };

        GetJobInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("Final Date", mDay + "/" + mMonth + "/" + mYear);
                Log.d("Final Time", mHour + ":" + mMinute);
                Intent intent = new Intent(MainActivity.this, JsonActivity.class);
                intent.putExtra("Hour",mHour);
                intent.putExtra("Minute", mMinute);
                intent.putExtra("Year",mYear);
                intent.putExtra("Month", mMonth);
                intent.putExtra("Day", mDay);
                startActivity(intent);
            }
        });
    }
}



